En la primera seccion de PL_Practica3_Memoria.pdf reflejamos todos los cambios de implementacion que hemos tomado con respecto
a la primera entrega y segunda entrega.

En la carpeta testFiles se encuentra un juego de pruebas. Estas son:
- Pruebas de fallos semanticos.
- Pruebas de generacion de codigo.

Para introducir un archivo al programa, debemos pasarlo como argumento en el main.
Al ejecutar un archivo, se creara otro llamada CodigoMaquina<nombreArchivo>.txt.