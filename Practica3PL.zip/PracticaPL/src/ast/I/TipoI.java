package ast.I;

public enum TipoI {
	IF, WHILE, SWITCH, ASIG, DECL, STRUCT, DECLFUN, CALLPROC
}
