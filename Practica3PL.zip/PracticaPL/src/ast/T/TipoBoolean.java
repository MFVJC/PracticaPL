package ast.T;

public class TipoBoolean extends Tipo{

	@Override
	public EnumeradoTipos tipoEnumerado() {
		return EnumeradoTipos.BOOLEAN;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Boolean";
	}

}
