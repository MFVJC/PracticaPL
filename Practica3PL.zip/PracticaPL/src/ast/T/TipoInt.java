package ast.T;

public class TipoInt extends Tipo{

	@Override
	public EnumeradoTipos tipoEnumerado() {
		return EnumeradoTipos.INT;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Int";
	}

}
