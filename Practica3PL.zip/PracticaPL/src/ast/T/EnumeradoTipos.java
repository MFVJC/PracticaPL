package ast.T;

public enum EnumeradoTipos {
	STRUCT, BOOLEAN, INT, PUNTERO, ARRAY, ERROR
}
