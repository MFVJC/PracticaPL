package ast.T;

public enum EnumeradoTipoGeneral {
	INSTRUCCION,EXPRESION,TIPOS, EXPRESION_BINARIA
}
